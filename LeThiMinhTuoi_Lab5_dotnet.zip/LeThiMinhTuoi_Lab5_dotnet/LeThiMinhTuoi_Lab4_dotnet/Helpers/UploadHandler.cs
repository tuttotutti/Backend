﻿namespace LeThiMinhTuoi_Lab4_dotnet.Helpers
{
    public class UploadHandler
    {
        public string Upload(IFormFile file)
        {
            List<string> validExtensions = new List<string> { ".jpg", ".jpeg", ".png", ".pdf" };

            var fileExtension = Path.GetExtension(file.FileName);
            if (!validExtensions.Contains(fileExtension))
            {
                return $"Extension is not valid ({string.Join(", ", validExtensions)})";
            }

            long size = file.Length;
            if (size > 5 * 1024 * 1024)
            {
                return "File size exceeds 5MB limit.";
            }

            string fileName = Guid.NewGuid().ToString() + fileExtension;
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
            using FileStream fs = new FileStream(Path.Combine(filePath, fileName), FileMode.Create);
            file.CopyTo(fs);

            return fileName;
        }
    }
}

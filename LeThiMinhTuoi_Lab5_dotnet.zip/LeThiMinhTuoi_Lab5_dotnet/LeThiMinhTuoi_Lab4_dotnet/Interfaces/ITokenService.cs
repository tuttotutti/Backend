﻿using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Interfaces
{
    public interface ITokenService
    {
        Task<string> GenerateJwtToken(User user);
    }
}

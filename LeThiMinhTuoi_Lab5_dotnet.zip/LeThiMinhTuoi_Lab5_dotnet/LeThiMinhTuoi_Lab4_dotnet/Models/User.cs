﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace LeThiMinhTuoi_Lab4_dotnet.Models
{
    public class User : IdentityUser
    {
        public string Address { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        public bool IsDeleted { get; set; } = false;

        public string Avatar { get; set; }

        public ICollection<Loan> Loans { get; set; }
    }
}

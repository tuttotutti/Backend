﻿using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Mappers;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/category")]
    [Authorize(Policy = "ManageActiveCategories")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;

        public CategoryController(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        [HttpGet]
        public async Task<IActionResult> getAllCategories([FromQuery] QueryObjectCategory query)
        {
            var categories = await _categoryRepository.getAllCategories(query);

            return Ok(categories);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> getCategoryById([FromRoute] int id)
        {
            var existingCategory = await _categoryRepository.GetCategoryById(id);

            if(existingCategory == null)
            {
                return Ok("Category not found");
            }

            return Ok(existingCategory);
        }


        [HttpPost]
        public async Task<IActionResult> addCategory([FromBody] CreatedCategoryDto createdCategoryDto)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var categoryModel = createdCategoryDto.CategoryFromCreatedCategoryDto();
            
            var createdCategory = await _categoryRepository.AddCategoryAsync(categoryModel);

            return CreatedAtAction(nameof(getCategoryById), new { id = createdCategory.CategoryId }, createdCategory);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> updateCategory([FromBody]  UpdatedCategoryDto updatedCategoryDto, [FromRoute] int id)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var categoryModel = updatedCategoryDto.CategoryFromUpdatedCategoryDto();

            var updatedCategory = await _categoryRepository.UpdateCategoryAsync(categoryModel, id);

            if(updatedCategory == null)
            {
                return Ok("Category not found");
            }

            return Ok(updatedCategory);
        }

        [HttpPatch("{id}/toggle")]
        public async Task<IActionResult> toggleStatus([FromRoute] int id)
        {
            var existingCategory = await _categoryRepository.ToggleStatusAsync(id);

            if(existingCategory == null)
            {
                return Ok("Category not found");
            }

            return Ok(existingCategory);
        }
    }
}

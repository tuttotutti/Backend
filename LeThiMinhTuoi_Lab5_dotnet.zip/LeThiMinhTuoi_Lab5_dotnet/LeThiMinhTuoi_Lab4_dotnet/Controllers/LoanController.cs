﻿using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Mappers;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/loan")]
    [ApiController]
    public class LoanController : ControllerBase
    {
        private readonly ILoanRepository _loanRepository;
        private readonly UserManager<User> _userManager;
        public LoanController(ILoanRepository loanRepository, UserManager<User> userManager)
        {
            _loanRepository = loanRepository;
            _userManager = userManager;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllLoans([FromQuery] QueryObjectLoan query)
        {
            var loans = await _loanRepository.GetAllLoan(query);

            return Ok(loans);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetLoanById([FromRoute] int id)
        {
            var exisitngLoan = await _loanRepository.GetLoanById(id);

            if (exisitngLoan == null)
            {
                return Ok("Loan not found");
            }

            return Ok(exisitngLoan);
        }

        [HttpPost]
        public async Task<IActionResult> AddLoan([FromBody] CreatedLoanDto createdLoanDto)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var loanModel = createdLoanDto.LoanFromCreatedLoan();

            var createdLoan = await _loanRepository.AddLoanAsync(loanModel);

            if(createdLoan == null)
            {
                return Ok("So sorry. This book is no longer available. T_T");
            }

            return CreatedAtAction(nameof(GetLoanById), new { id = createdLoan.LoanId }, createdLoan);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateLoan([FromBody] UpdatedLoanDto updatedLoanDto, [FromRoute] int id)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var loanModel = updatedLoanDto.LoanFromUpdatedLoan();

            var updatedLoan = await _loanRepository.UpdateLoanAsync(loanModel, id);

            if(updatedLoan == null)
            {
                return Ok("Loan not found");
            }

            return Ok(updatedLoan);
        }

        [HttpGet("history")]
        [Authorize(Policy = "MinimumMembership")]
        public async Task<IActionResult> GetLoanHistory()
        {
            var existingUserName = User.Identity?.Name.ToLower();

            var existingUser = await _userManager.Users.Include(u => u.Loans).FirstOrDefaultAsync(u => u.UserName.ToLower() == existingUserName);

            if (existingUser == null)
            {
                return NotFound("User not found.");
            }

            var loanHistory = existingUser.Loans.ToList();

            return Ok(loanHistory);
        }
    }
}

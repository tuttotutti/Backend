﻿using LeThiMinhTuoi_Lab4_dotnet.Dtos.UserDto;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/account")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly ITokenService _tokenService;

        public AuthController(UserManager<User> userManager, SignInManager<User> signInManager, ITokenService tokenService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _tokenService = tokenService;
        }

        // username: tuoiadmin, password: Tuoi123&Tuoi123&
        // username: tuoi1, password: Tuoi123&
        // username: tuoilib, password: Borrower12345%
        // username: tuoiinactive, password: Admin222@@@@
        // username: tuoioneyear, password: Librarian222@@@@
        // username: tuoiinvalidemail, password: Tuoi123&
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody]LoginRequestDto loginRequestDto)
        {
            var existingUser = await _userManager.Users.FirstOrDefaultAsync(u => u.UserName.ToLower() == loginRequestDto.Username.ToLower());

            if(existingUser == null)
            {
                return Unauthorized("Username or password is incorrect");
            }

            var checkPassword = await _signInManager.CheckPasswordSignInAsync(existingUser, loginRequestDto.Password, false);

            if(!checkPassword.Succeeded)
            {
                return Unauthorized("Username or password is incorrect");
            }

            var token = await _tokenService.GenerateJwtToken(existingUser);

            return Ok(new {token});
        }

        [Authorize]
        [HttpPost("hash-password")]
        public IActionResult HashPassword([FromBody] string password)
        {
            var passwordHasher = new PasswordHasher<User>();
            var hashedPassword = passwordHasher.HashPassword(null, password);
            return Ok(new { hashedPassword });
        }
    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        public UserController(UserManager<User> userManager)
        {
            _userManager = userManager;
        }

        [HttpGet("me")]
        [Authorize]
        public IActionResult GetMe()
        {
            var username = User.Identity?.Name;
            var role = User.FindFirst(ClaimTypes.Role)?.Value;
            return Ok(new { username, role });
        }

        [HttpGet("dashboard")]
        [Authorize(Roles = "Admin")]
        public IActionResult AdminDashboard()
        {
            return Ok("Welcome, Admin!");
        }

        [HttpGet("active-user-list")]
        [Authorize(Policy = "ActiveUserOnly")]
        public async Task<IActionResult> GetActiveUserList()
        {
            var activeUsers = await _userManager.Users.Where(u => u.IsDeleted == false).ToListAsync();
            return Ok(activeUsers);
        }
    }
}

﻿using System.Runtime.InteropServices;
using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Dtos.Book;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Mappers;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/book")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IBookRepository _bookRepo;

        public BookController(IBookRepository bookRepo)
        {
            _bookRepo = bookRepo;
        }

        [HttpGet]
        public async Task<IActionResult> getAllBooksAsync([FromQuery] QueryObject query)
        {
            var books = await _bookRepo.getAllBooksAsync(query);

            return Ok(books);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> getBookById([FromRoute] int id)
        {
            var book = await _bookRepo.getBookByIdAsync(id);
            
            if(book == null)
            {
                return Ok("The book does not exist.");
            }

            return Ok(book);
        }

        [HttpPost]
        public async Task<IActionResult> addBook([FromBody] CreatedBookDto createdBookDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var bookModel = createdBookDto.BookFromCreatedBookDto();

            var createdBook = await _bookRepo.addBookAsync(bookModel);

            return CreatedAtAction(nameof(getBookById), new { id = bookModel.BookId}, bookModel);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> updateBook([FromRoute] int id, [FromBody] UpdatedBookDto updatedBookDto)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var bookModel = updatedBookDto.BookFromUpdatedBookDto();

            var updatedBook = await _bookRepo.updateBookAsync(bookModel, id);
            
            if(updatedBook== null)
            {
                return Ok("Book not found");
            }

            return Ok(updatedBook);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> deleteBook([FromRoute] int id)
        {
            var deletedBook = await _bookRepo.deleteBookAsync(id);

            if(deletedBook == null)
            {
                return Ok("Book not found");
            }

            return NoContent();
        }

        [HttpGet("deleted")]
        public async Task<IActionResult> getDeletedBooks()
        {
            var deletedBooks = await _bookRepo.getDeletedBooksAsync();

            return Ok(deletedBooks);
        }

        [HttpPatch("{id}/restore")]
        public async Task<IActionResult> restoreBook([FromRoute] int id)
        {
            var exisitngBook = await _bookRepo.restoreBookAsync(id);

            if(exisitngBook == null)
            {
                return Ok("Book not found");
            }

            return Ok(exisitngBook);
        }

        [HttpDelete("{id}/hard")]
        public async Task<IActionResult> deleteBookHard([FromRoute] int id)
        {
            var exisitngBook = await _bookRepo.deleteBookHardAsync(id);

            if(exisitngBook == null)
            {
                return Ok("Book not found");
            }

            return NoContent();
        }

        [HttpGet("{id}/read")]
        public async Task<IActionResult> ReadBookPdf([FromRoute] int id)
        {
            var book = await _bookRepo.getBookByIdAsync(id);

            if (book == null)
            {
                return NotFound(new { message = "Book not found." });
            }

            if (string.IsNullOrEmpty(book.Pdf))
            {
                return NotFound(new { message = "PDF file not available for this book." });
            }

            var pdfRelativeUrl = $"{book.Pdf}";
            return Ok(new { pdfUrl = pdfRelativeUrl });
        }

        [HttpPost("upload")]
        [Authorize(Policy = "VerifiedEmailOnly")]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { message = "No file uploaded." });
            }
            
            return Ok(new UploadHandler().Upload(file));
        }
    }
}

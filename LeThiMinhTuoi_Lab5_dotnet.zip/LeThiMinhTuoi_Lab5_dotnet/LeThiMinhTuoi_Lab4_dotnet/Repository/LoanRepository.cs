﻿using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Repository
{
    public class LoanRepository : ILoanRepository
    {
        private readonly LibraryDbContext _context;

        public LoanRepository(LibraryDbContext context)
        {
            _context = context;
        }

        public async Task<Loan> AddLoanAsync(Loan loan)
        {
            var book = await _context.Books.FirstOrDefaultAsync(b => b.BookId == loan.BookId);

            if(book == null)
            {
                return null;
            }

            if(book.AvailableCopies == 0)
            {
                return null;
            }

            await _context.Loans.AddAsync(loan);
            await _context.SaveChangesAsync();

            return loan;
        }

        public async Task<List<Loan>> GetAllLoan(QueryObjectLoan query)
        {
            var loans = _context.Loans.Include(l => l.Book).ThenInclude(b => b.Author).Include(l => l.Book).ThenInclude(b => b.Category).AsQueryable();

            if(!string.IsNullOrEmpty(query.UserId))
            {
                loans = loans.Where(l => l.User.Id == query.UserId);
            }

            if(query.Status.HasValue)
            {
                loans = loans.Where(l => l.Status == query.Status);
            }

            if(query.LoanDate.HasValue)
            {
                loans = loans.Where(l => l.LoanDate == query.LoanDate);
            }

            return await loans.ToListAsync();
        }

        public async Task<Loan> GetLoanById(int id)
        {
            var existingLoan = await _context.Loans.Include(l => l.Book).ThenInclude(b => b.Author).Include(l => l.Book).ThenInclude(b => b.Category).FirstOrDefaultAsync(l => l.LoanId == id);

            if(existingLoan == null)
            {
                return null;
            }

            return existingLoan;
        }

        public async Task<Loan> UpdateLoanAsync(Loan loan, int id)
        {
            var existingLoan = await _context.Loans.FirstOrDefaultAsync(l => l.LoanId == id);

            if (existingLoan == null)
            {
                return null;
            }

            existingLoan.User.Id = loan.User.Id;
            existingLoan.BookId = loan.BookId;
            existingLoan.LoanDate = loan.LoanDate;
            existingLoan.DueDate = loan.DueDate;

            if(loan.ReturnDate.HasValue & loan.ReturnDate != existingLoan.ReturnDate)
            {
                existingLoan.ReturnDate = loan.ReturnDate;
                existingLoan.Status = LoanStatus.Returned;
            }

            await _context.SaveChangesAsync();

            return existingLoan;
        }
    }
}
﻿using System.ComponentModel.DataAnnotations;

namespace LeThiMinhTuoi_Lab4_dotnet.Dtos.UserDto
{
    public class LoginRequestDto
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace LeThiMinhTuoi_Lab4_dotnet.Models
{
    public class UpdatedLoanDto
    {

        [Required]
        public User user { get; set; }
        [Required]
        public int BookId { get; set; }
        public DateTime LoanDate { get; set; } = DateTime.UtcNow;

        public DateTime? DueDate { get; set; }

        public DateTime? ReturnDate { get; set; }

        public LoanStatus Status { get; } = LoanStatus.Active;
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LeThiMinhTuoi_Lab4_dotnet.Migrations
{
    /// <inheritdoc />
    public partial class addIsActiveToBook : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                table: "Books",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsActive",
                table: "Books");
        }
    }
}

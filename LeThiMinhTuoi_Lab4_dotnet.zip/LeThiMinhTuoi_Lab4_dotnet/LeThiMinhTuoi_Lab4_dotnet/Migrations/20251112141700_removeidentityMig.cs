﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LeThiMinhTuoi_Lab4_dotnet.Migrations
{
    /// <inheritdoc />
    public partial class removeidentityMig : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

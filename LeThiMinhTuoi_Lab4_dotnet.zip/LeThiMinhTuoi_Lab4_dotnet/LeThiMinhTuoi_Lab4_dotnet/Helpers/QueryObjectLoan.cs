﻿using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Helpers
{
    public class QueryObjectLoan
    {
        public int? UserId { get; set; }
        public LoanStatus? Status { get; set; }
        public DateTime? LoanDate { get; set; }
    }
}

﻿namespace LeThiMinhTuoi_Lab4_dotnet.Helpers
{
    public class QueryObject
    {
        public String? Title { get; set; } = String.Empty;
        public int? CategoryId { get; set; }
        public int? AuthorId { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 9;
    }
}

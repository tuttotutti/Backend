﻿namespace LeThiMinhTuoi_Lab4_dotnet.Helpers
{
    public class QueryObjectAuthor
    {
        public string? AuthorName { get; set; } = String.Empty;
    }
}

﻿namespace LeThiMinhTuoi_Lab4_dotnet.Helpers
{
    public class QueryObjectTopBook
    {
        public DateTime? fromTime {  get; set; }
        public DateTime? toTime { get; set; }
        public int top { get; set; } = 10;
    }
}

﻿namespace LeThiMinhTuoi_Lab4_dotnet.Helpers
{
    public class QueryObjectCategory
    {
        public string? CategoryName { get; set; } = String.Empty;
        public bool? IsActive { get; set; }
    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Interfaces
{
    public interface IAuthorRepository
    {
        Task<List<Author>> getAllAuthor(QueryObjectAuthor query);
        Task<Author> GetAuthorByIdAsync(int id);
        Task<Author> AddAuthorAsync(Author author);
        Task<Author> UpdateAuthorAsync(Author author, int id);
        Task<Author> DeleteAuthorAsync(int id);
    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Interfaces
{
    public interface IBookRepository
    {
        Task<List<Book>> getAllBooksAsync(QueryObject query);
        Task<Book> getBookByIdAsync(int id);
        Task<Book> addBookAsync(Book book);
        Task<Book> updateBookAsync(Book book, int id);
        Task<Book> deleteBookAsync(int id);
        Task<List<Book>> getDeletedBooksAsync();
        Task<Book> restoreBookAsync(int id);
        Task<Book> deleteBookHardAsync(int id);
    }
}

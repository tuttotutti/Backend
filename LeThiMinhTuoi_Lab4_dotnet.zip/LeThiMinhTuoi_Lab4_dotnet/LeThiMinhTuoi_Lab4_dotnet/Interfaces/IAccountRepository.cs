﻿using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Interfaces
{
    public interface IAccountRepository
    {
        Task<User> registerUsersync(User user);
    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Interfaces
{
    public interface ICarouselRepository
    {
        Task<List<CarouselItem>> GetAllCarouselAsync();
        Task<CarouselItem> GetCarouselByIdAsync(int id);
        Task<CarouselItem> CreateCarouselItemAsync(CarouselItem carouselItem);
        Task<CarouselItem> UpdateCarouselItemAsync(CarouselItem carouselItem, int id);
        Task<CarouselItem> DeleteCarousalItemAsync(int id);
    }
}

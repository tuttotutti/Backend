﻿using LeThiMinhTuoi_Lab4_dotnet.Dtos.BookDto;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Interfaces
{
    public interface IReportRepository
    {
        Task<List<TopBorrowedBookDto>> GetTopBorrowedBooksAsync(QueryObjectTopBook query);
    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Mvc;

namespace LeThiMinhTuoi_Lab4_dotnet.Interfaces
{
    public interface ICategoryRepository
    {
        Task<List<Category>> getAllCategories(QueryObjectCategory query);
        Task<Category> AddCategoryAsync(Category category);
        Task<Category> GetCategoryById(int id);
        Task<Category> ToggleStatusAsync(int id);
        Task<Category> UpdateCategoryAsync(Category updatedCategoryDto, int id);
    }
}

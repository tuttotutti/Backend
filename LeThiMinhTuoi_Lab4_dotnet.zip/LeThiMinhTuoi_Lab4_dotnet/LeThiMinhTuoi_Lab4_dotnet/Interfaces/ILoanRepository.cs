﻿using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Interfaces
{
    public interface ILoanRepository
    {
        Task<List<Loan>> GetAllLoan(QueryObjectLoan query);
        Task<Loan> GetLoanById(int id);
        Task<Loan> AddLoanAsync(Loan loan);
        Task<Loan> UpdateLoanAsync(Loan loan, int id);
    }
}

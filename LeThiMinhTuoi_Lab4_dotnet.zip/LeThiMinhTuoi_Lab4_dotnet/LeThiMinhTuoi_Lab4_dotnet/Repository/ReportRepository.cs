﻿using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Dtos.BookDto;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Repository
{
    public class ReportRepository : IReportRepository
    {
        private readonly LibraryDbContext _context;

        public ReportRepository(LibraryDbContext context)
        {
            _context = context;
        }

        public async Task<List<TopBorrowedBookDto>> GetTopBorrowedBooksAsync(QueryObjectTopBook query)
        {
            var topBooks = _context.Loans
                                    .Where(l => l.LoanDate >= query.fromTime && l.LoanDate <= query.toTime)
                                    .GroupBy(l => new { l.BookId, l.Book.Title })
                                    .Select(g => new TopBorrowedBookDto
                                    {
                                        BookId = g.Key.BookId,
                                        Title = g.Key.Title,
                                        BorrowCount = g.Count()
                                    })
                                    .OrderByDescending(b => b.BorrowCount)
                                    .Take(query.top);

            return await topBooks.ToListAsync();
        }
    }
}

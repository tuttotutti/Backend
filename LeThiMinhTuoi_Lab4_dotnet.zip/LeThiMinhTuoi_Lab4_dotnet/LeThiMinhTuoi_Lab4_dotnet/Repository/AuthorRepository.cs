﻿using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Repository
{
    public class AuthorRepository : IAuthorRepository
    {
        private readonly LibraryDbContext _context;

        public AuthorRepository(LibraryDbContext context)
        {
            _context = context;
        }

        public async Task<Author> AddAuthorAsync(Author author)
        {
            await _context.Authors.AddAsync(author);
            await _context.SaveChangesAsync();  

            return author;
        }

        public async Task<Author> DeleteAuthorAsync(int id)
        {
            var exisitngAuthor = await _context.Authors.FirstOrDefaultAsync(a => a.AuthorId == id);

            if(exisitngAuthor == null)
            {
                return null;
            }

            exisitngAuthor.IsActive = false;
            await _context.SaveChangesAsync();

            return exisitngAuthor;
        }

        public async Task<List<Author>> getAllAuthor(QueryObjectAuthor query)
        {
            var authors = _context.Authors.Include(a => a.Books).AsQueryable();

            if(!string.IsNullOrWhiteSpace(query.AuthorName))
            {
                authors = authors.Where(a => a.FirstName.ToLower().Contains(query.AuthorName.ToLower()));
            }

            return await authors.ToListAsync();
        }

        public async Task<Author> GetAuthorByIdAsync(int id)
        {
            var existingAuthor = await _context.Authors.FirstOrDefaultAsync(a => a.AuthorId == id);

            if (existingAuthor == null)
            {
                return null;
            }

            return existingAuthor;
        }

        public async Task<Author> UpdateAuthorAsync(Author author, int id)
        {
            var existingAuthor = await _context.Authors.FirstOrDefaultAsync(a => a.AuthorId == id);

            if(existingAuthor == null)
            {
                return null;
            }

            existingAuthor.FirstName = author.FirstName;
            existingAuthor.LastName = author.LastName;
            existingAuthor.DateOfBirth = author.DateOfBirth;
            existingAuthor.Biography = author.Biography;
            existingAuthor.Nationality = author.Nationality;
            existingAuthor.Email = author.Email;
            existingAuthor.Website = author.Website;
            existingAuthor.CreatedDate = author.CreatedDate;
            existingAuthor.IsActive = author.IsActive;
            existingAuthor.Avatar = author.Avatar;
            existingAuthor.Books = author.Books;

            await _context.SaveChangesAsync();

            return existingAuthor;
        }
    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly LibraryDbContext _context;

        public CategoryRepository(LibraryDbContext context)
        {
            _context = context;
        }

        public async Task<Category> AddCategoryAsync(Category category)
        {
            await _context.Categories.AddAsync(category);
            await _context.SaveChangesAsync();

            return category;
        }

        public async Task<List<Category>> getAllCategories(QueryObjectCategory query)
        {
            var categories = _context.Categories.AsQueryable();

            if(!string.IsNullOrEmpty(query.CategoryName))
            {
                categories = categories.Where(c => c.Name.ToLower().Contains(query.CategoryName.ToLower()));
            }

            if(query.IsActive.HasValue)
            {
                categories = categories.Where(c => c.IsActive ==  query.IsActive.Value);
            }

            return await categories.ToListAsync();
        }

        public async Task<Category> GetCategoryById(int id)
        {
            var existingCategory = await _context.Categories.FirstOrDefaultAsync(c => c.CategoryId == id);

            if (existingCategory == null)
            {
                return null;
            }

            return existingCategory;
        }

        public async Task<Category> ToggleStatusAsync(int id)
        {
            var existingCategory = await _context.Categories.FirstOrDefaultAsync(c => c.CategoryId == id);

            if(existingCategory == null)
            {
                return null;
            }

            existingCategory.IsActive = !existingCategory.IsActive;

            await _context.SaveChangesAsync();

            return existingCategory;
        }

        public async Task<Category> UpdateCategoryAsync(Category updatedCategoryDto, int id)
        {
            var existingCategory = await _context.Categories.FirstOrDefaultAsync(c => c.CategoryId == id);

            if(existingCategory == null) {
                return null;
            }

            existingCategory.Name = updatedCategoryDto.Name;
            existingCategory.Description = updatedCategoryDto.Description;
            existingCategory.CreatedDate = updatedCategoryDto.CreatedDate;
            existingCategory.UpdatedDate = updatedCategoryDto.UpdatedDate;
            existingCategory.IsActive = updatedCategoryDto.IsActive;
            existingCategory.Avatar = updatedCategoryDto.Avatar;

            await _context.SaveChangesAsync();

            return existingCategory;
        }
    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Repository
{
    public class CarouselRepository : ICarouselRepository
    {
        private readonly LibraryDbContext _context;

        public CarouselRepository(LibraryDbContext context)
        {
            _context = context;
        }

        public async Task<List<CarouselItem>> GetAllCarouselAsync()
        {
            var carouselItems = await _context.CarouselItems.ToListAsync();
            return carouselItems;
        }

        public async Task<CarouselItem> GetCarouselByIdAsync(int id)
        {
            var existingCarousel = await _context.CarouselItems.FirstOrDefaultAsync(c => c.CarouselId == id);

            if(existingCarousel == null)
            {
                return null;
            }

            return existingCarousel;
        }

        public async Task<CarouselItem> CreateCarouselItemAsync(CarouselItem carouselItem)
        {
            await _context.CarouselItems.AddAsync(carouselItem); 
            await _context.SaveChangesAsync();

            return carouselItem;
        }

        public async Task<CarouselItem> UpdateCarouselItemAsync(CarouselItem carouselItem, int id)
        {
            var existingCarousalItem = await _context.CarouselItems.FirstOrDefaultAsync(c => c.CarouselId == id);

            if(existingCarousalItem == null)
            {
                return null;
            }

            existingCarousalItem.ImageUrl = carouselItem.ImageUrl;
            existingCarousalItem.Title = carouselItem.Title;
            existingCarousalItem.Description = carouselItem.Description;
            existingCarousalItem.LinkUrl = carouselItem.LinkUrl;
            existingCarousalItem.Order = carouselItem.Order;
            existingCarousalItem.UpdatedDate = carouselItem.UpdatedDate;

            await _context.SaveChangesAsync();

            return existingCarousalItem;
        }

        public async Task<CarouselItem> DeleteCarousalItemAsync(int id)
        {
            var existingCarousalItem = await _context.CarouselItems.FirstOrDefaultAsync(c => c.CarouselId == id);

            if(existingCarousalItem == null)
            {
                return null;
            }

            var imageFileName = Path.GetFileName(new Uri(existingCarousalItem.ImageUrl).LocalPath);
            var imagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "carousel_images", imageFileName);

            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }


            _context.CarouselItems.Remove(existingCarousalItem);
            await _context.SaveChangesAsync();

            return existingCarousalItem;
        }
    }
}

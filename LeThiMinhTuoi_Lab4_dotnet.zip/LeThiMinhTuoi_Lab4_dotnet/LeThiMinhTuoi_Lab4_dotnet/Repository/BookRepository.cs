﻿using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Repository
{
    public class BookRepository : IBookRepository
    {
        private readonly LibraryDbContext _context;

        public BookRepository(LibraryDbContext context)
        {
            _context = context;
        }

        public async Task<Book> addBookAsync(Book book)
        {
            await _context.Books.AddAsync(book);
            await _context.SaveChangesAsync();

            return book;
        }

        public async Task<Book> deleteBookAsync(int id)
        {
            var existingBook = await _context.Books.FirstOrDefaultAsync(b => b.BookId == id);

            if(existingBook == null)
            {
                return null;
            }

            existingBook.IsActive = false;

            await _context.SaveChangesAsync();

            return existingBook;
        }

        public async Task<Book> deleteBookHardAsync(int id)
        {
            var existingBook = await _context.Books.FirstOrDefaultAsync(b => b.BookId == id);

            if(existingBook == null)
            {
                return null;
            }

            var imageFileName = Path.GetFileName(new Uri(existingBook.Avatar).LocalPath);
            var imagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "carousel_images", imageFileName);

            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }

            var pdfFileName = Path.GetFileName(new Uri(existingBook.Pdf).LocalPath);
            var pdfPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "carousel_images", pdfFileName);

            if (System.IO.File.Exists(pdfPath))
            {
                System.IO.File.Delete(pdfPath);
            }

            _context.Books.Remove(existingBook);
            await _context.SaveChangesAsync();

            return existingBook;
        }

        public async Task<List<Book>> getAllBooksAsync(QueryObject query)
        {
            var books = _context.Books.AsQueryable();

            if (!string.IsNullOrWhiteSpace(query.Title))
            {
                books = books.Where(b => b.Title.ToLower().Contains(query.Title.ToLower()));
            }

            if(query.AuthorId.HasValue & query.AuthorId > 0)
            {
                books = books.Where(b => b.AuthorId == query.AuthorId);
            }

            if(query.CategoryId.HasValue & query.CategoryId > 0)
            {
                books = books.Where(b => b.CategoryId == query.CategoryId);
            }

            var skipNumber = (query.PageNumber - 1) * query.PageSize;

            return await books.Skip(skipNumber).Take(query.PageSize).ToListAsync();
        }

        public async Task<Book> getBookByIdAsync(int id)
        {
            var book = await _context.Books.FirstOrDefaultAsync(b => b.BookId == id);

            return book;
        }

        public async Task<List<Book>> getDeletedBooksAsync()
        {
            var deletedBooks = await _context.Books.Where(b => b.IsActive == false).ToListAsync();

            return deletedBooks;
        }

        public async Task<Book> restoreBookAsync(int id)
        {
            var exisitngBook = await _context.Books.FirstOrDefaultAsync(b => b.BookId == id);

            if(exisitngBook == null)
            {
                return null;
            }

            exisitngBook.IsActive = true;

            await _context.SaveChangesAsync();

            return exisitngBook;
        }

        public async Task<Book> updateBookAsync(Book book, int id)
        {
            var existingBook = await _context.Books.FirstOrDefaultAsync(b => b.BookId == id);

            if (existingBook == null)
            {
                return null;
            }

            existingBook.Title = book.Title;
            existingBook.Description = book.Description;
            existingBook.BookCode = book.BookCode;
            existingBook.Publisher = book.Publisher;
            existingBook.PublishedYear = book.PublishedYear;
            existingBook.CategoryId = book.CategoryId;
            existingBook.AuthorId = book.AuthorId;
            existingBook.TotalCopies = book.TotalCopies;
            existingBook.AvailableCopies = book.AvailableCopies;
            existingBook.Avatar = book.Avatar;
            existingBook.Pdf = book.Pdf;

            await _context.SaveChangesAsync();

            return existingBook;
        }
    }
}

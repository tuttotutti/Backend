﻿using System.ComponentModel.DataAnnotations;

namespace LeThiMinhTuoi_Lab4_dotnet.Dtos.Carousel
{
    public class CreatedCarouselItemDto
    {
        [Required]
        public string ImageUrl { get; set; } = null!;

        [Required]
        [MaxLength(200)]
        public string Title { get; set; } = null!;

        public string? Description { get; set; }

        public string? LinkUrl { get; set; }

        [Required]
        public int Order { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    }
}


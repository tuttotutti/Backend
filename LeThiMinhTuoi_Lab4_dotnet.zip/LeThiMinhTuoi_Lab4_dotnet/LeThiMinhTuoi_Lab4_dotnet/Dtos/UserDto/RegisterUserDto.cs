﻿using System.ComponentModel.DataAnnotations;
using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Dtos.UserDto
{
    public class RegisterUserDto
    {
        [Required, StringLength(200)]
        public string Fullname { get; set; }

        public string Description { get; set; }

        [Required]
        public string Password { get; set; }

        [Required, EmailAddress, StringLength(100)]
        public string Email { get; set; }

        [Phone, StringLength(20)]
        public string Phone { get; set; }

        public string Address { get; set; }

        public int Status { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        public string UserCode { get; set; }

        public bool IsLocked { get; set; } = false;

        public bool IsDeleted { get; set; } = false;

        public bool IsActive { get; set; } = true;

        public string ActiveCode { get; set; }

        public string Avatar { get; set; }
}
}

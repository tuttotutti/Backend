﻿using System.ComponentModel.DataAnnotations;

namespace LeThiMinhTuoi_Lab4_dotnet.Dtos.UserDto
{
    public class ActivateUserDto
    {
        [Required]
        public string Code { get; set; }
    }
}

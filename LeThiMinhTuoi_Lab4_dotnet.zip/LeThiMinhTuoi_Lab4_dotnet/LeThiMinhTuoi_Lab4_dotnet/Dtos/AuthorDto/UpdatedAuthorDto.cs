﻿using System.ComponentModel.DataAnnotations;

namespace LeThiMinhTuoi_Lab4_dotnet.Models
{
    public class UpdatedAuthorDto
    {
        [StringLength(100)]
        public string FirstName { get; set; }

        [StringLength(100)]
        public string LastName { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public string Biography { get; set; }

        [StringLength(100)]
        public string Nationality { get; set; }

        [EmailAddress, StringLength(100)]
        public string Email { get; set; }

        [StringLength(100)]
        public string Website { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        public bool IsActive { get; set; } = true;

        public string Avatar { get; set; }

    }
}

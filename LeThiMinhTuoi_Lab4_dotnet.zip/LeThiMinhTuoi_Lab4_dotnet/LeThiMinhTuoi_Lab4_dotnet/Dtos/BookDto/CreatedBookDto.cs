﻿using System.ComponentModel.DataAnnotations;
using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Dtos.Book
{
    public class CreatedBookDto
    {
        [Required, StringLength(200)]
        public string Title { get; set; }

        public string Description { get; set; }

        public string BookCode { get; set; }

        public string Publisher { get; set; }

        public DateTime? PublishedYear { get; set; }

        public int? CategoryId { get; set; }

        public int? AuthorId { get; set; }

        public int TotalCopies { get; set; } = 0;

        public int AvailableCopies { get; set; } = 0;

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        public string Avatar { get; set; }

        public string Pdf { get; set; }

        public Boolean IsActive { set; get; } = true;
    }
}

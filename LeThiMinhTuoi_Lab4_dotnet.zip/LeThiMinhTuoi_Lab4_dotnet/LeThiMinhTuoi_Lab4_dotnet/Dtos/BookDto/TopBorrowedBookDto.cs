﻿namespace LeThiMinhTuoi_Lab4_dotnet.Dtos.BookDto
{
    public class TopBorrowedBookDto
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public int BorrowCount { get; set; }
    }
}

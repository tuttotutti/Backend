﻿using LeThiMinhTuoi_Lab4_dotnet.Dtos.Book;
using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Mappers
{
    public static class BookMapper
    {
        public static Book BookFromCreatedBookDto(this CreatedBookDto createdBookDto)
        {
            return new Book
            {
                Title = createdBookDto.Title,
                Description = createdBookDto.Description,
                BookCode = createdBookDto.BookCode,
                Publisher = createdBookDto.Publisher,
                PublishedYear = createdBookDto.PublishedYear,
                CategoryId = createdBookDto.CategoryId,
                AuthorId = createdBookDto.AuthorId,
                TotalCopies = createdBookDto.TotalCopies,
                AvailableCopies = createdBookDto.AvailableCopies,
                Avatar = createdBookDto.Avatar,
                Pdf = createdBookDto.Pdf,
                IsActive = createdBookDto.IsActive,
            };
        }

        public static Book BookFromUpdatedBookDto(this UpdatedBookDto updatedBookDto)
        {
            return new Book
            {
                Title = updatedBookDto.Title,
                Description = updatedBookDto.Description,
                BookCode = updatedBookDto.BookCode,
                Publisher = updatedBookDto.Publisher,
                PublishedYear = updatedBookDto.PublishedYear,
                CategoryId = updatedBookDto.CategoryId,
                AuthorId = updatedBookDto.AuthorId,
                TotalCopies = updatedBookDto.TotalCopies,
                AvailableCopies = updatedBookDto.AvailableCopies,
                Avatar = updatedBookDto.Avatar,
                Pdf = updatedBookDto.Pdf,
                IsActive = updatedBookDto.IsActive,
            };
        }

    }
}

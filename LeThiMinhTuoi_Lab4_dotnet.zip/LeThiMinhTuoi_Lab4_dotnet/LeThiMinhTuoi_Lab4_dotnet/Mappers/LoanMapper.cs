﻿using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Mappers
{
    public static class LoanMapper
    {
        public static Loan LoanFromCreatedLoan(this CreatedLoanDto createdLoanDto)
        {
            return new Loan
            {
                UserId = createdLoanDto.UserId,
                BookId = createdLoanDto.BookId,
                LoanDate = createdLoanDto.LoanDate,
                DueDate = createdLoanDto.DueDate,
                ReturnDate = createdLoanDto.ReturnDate,
                Status = createdLoanDto.Status
            };
        }

        public static Loan LoanFromUpdatedLoan(this UpdatedLoanDto updatedLoanDto)
        {
            return new Loan
            {
                UserId = updatedLoanDto.UserId,
                BookId = updatedLoanDto.BookId,
                LoanDate = updatedLoanDto.LoanDate,
                DueDate = updatedLoanDto.DueDate,
                ReturnDate = updatedLoanDto.ReturnDate,
                Status = updatedLoanDto.Status
            };
        }

    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Dtos.Carousel;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Mappers
{
    public static class CarouselMapper
    {
        public static CarouselItem ToCarouselItemFromCreated(this CreatedCarouselItemDto createdCarouselItemDto)
        {
            return new CarouselItem
            {
                ImageUrl = createdCarouselItemDto.ImageUrl,
                Title = createdCarouselItemDto.Title,
                Description = createdCarouselItemDto.Description,
                LinkUrl = createdCarouselItemDto.LinkUrl,
                Order = createdCarouselItemDto.Order,
                IsActive = createdCarouselItemDto.IsActive,
                CreatedDate = createdCarouselItemDto.CreatedDate,
            };
        }

        public static CarouselItem ToCarouselItemFromUpdated(this UpdatedCarouselItemDto updatedCarouselItemDto)
        {
            return new CarouselItem
            {
                ImageUrl = updatedCarouselItemDto.ImageUrl,
                Title = updatedCarouselItemDto.Title,
                Description = updatedCarouselItemDto.Description,
                LinkUrl = updatedCarouselItemDto.LinkUrl,
                Order = updatedCarouselItemDto.Order,
                IsActive = updatedCarouselItemDto.IsActive,
                UpdatedDate = updatedCarouselItemDto.UpdatedDate,
            };
        }

    }
}

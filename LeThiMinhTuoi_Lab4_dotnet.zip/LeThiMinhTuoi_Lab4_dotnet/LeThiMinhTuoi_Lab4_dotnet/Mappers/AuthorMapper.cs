﻿using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Mappers
{
    public static class AuthorMapper
    {
        public static Author AuthorFromUpdateddAuthorDto(this UpdatedAuthorDto updatedAuthorDto)
        {
            return new Author
            {
                FirstName = updatedAuthorDto.FirstName,
                LastName = updatedAuthorDto.LastName,
                DateOfBirth = updatedAuthorDto.DateOfBirth,
                Biography = updatedAuthorDto.Biography,
                Nationality = updatedAuthorDto.Nationality,
                Email = updatedAuthorDto.Email,
                Website = updatedAuthorDto.Website,
                CreatedDate = updatedAuthorDto.CreatedDate,
                IsActive = updatedAuthorDto.IsActive,
                Avatar = updatedAuthorDto.Avatar,
            };
        }

        public static Author AuthorFromCreatedAuthorDto(this CreatedAuthorDto createdAuthorDto)
        {
            return new Author
            {
                FirstName = createdAuthorDto.FirstName,
                LastName = createdAuthorDto.LastName,
                DateOfBirth = createdAuthorDto.DateOfBirth,
                Biography = createdAuthorDto.Biography,
                Nationality = createdAuthorDto.Nationality,
                Email = createdAuthorDto.Email,
                Website = createdAuthorDto.Website,
                CreatedDate = createdAuthorDto.CreatedDate,
                IsActive = createdAuthorDto.IsActive,
                Avatar = createdAuthorDto.Avatar,
            };
        }

    }
}

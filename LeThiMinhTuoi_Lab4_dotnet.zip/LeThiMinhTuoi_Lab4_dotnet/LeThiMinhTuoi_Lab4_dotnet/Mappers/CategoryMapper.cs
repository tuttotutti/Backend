﻿using LeThiMinhTuoi_Lab4_dotnet.Models;

namespace LeThiMinhTuoi_Lab4_dotnet.Mappers
{
    public static class CategoryMapper
    {
        public static Category CategoryFromCreatedCategoryDto(this CreatedCategoryDto createdCategoryDto)
        {
            return new Category
            {
                Name = createdCategoryDto.Name,
                Description = createdCategoryDto.Description,
                CreatedDate = createdCategoryDto.CreatedDate,
                UpdatedDate = createdCategoryDto.UpdatedDate,
                IsActive = createdCategoryDto.IsActive,
                Avatar = createdCategoryDto.Avatar,
            };
        }

        public static Category CategoryFromUpdatedCategoryDto(this UpdatedCategoryDto updatedCategoryDto)
        {
            return new Category
            {
                Name = updatedCategoryDto.Name,
                Description = updatedCategoryDto.Description,
                CreatedDate = updatedCategoryDto.CreatedDate,
                UpdatedDate = updatedCategoryDto.UpdatedDate,
                IsActive = updatedCategoryDto.IsActive,
                Avatar = updatedCategoryDto.Avatar,
            };
        }

    }
}

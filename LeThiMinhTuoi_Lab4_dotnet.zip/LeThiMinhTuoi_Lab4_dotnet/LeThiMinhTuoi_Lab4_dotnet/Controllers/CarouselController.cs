﻿using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Dtos.Carousel;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Mappers;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Mvc;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/carousel")]
    [ApiController]
    public class CarouselController :ControllerBase
    {
        private readonly ICarouselRepository _carouselRepo;

        public CarouselController(ICarouselRepository carouselRepo)
        {
            _carouselRepo = carouselRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllCarouselItemsAsync()
        {
            var carouselItems = await _carouselRepo.GetAllCarouselAsync();
            var carouselItemDtos = carouselItems.ToList();

            return Ok(carouselItemDtos);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetCarouselById([FromRoute] int id)
        {
            var existingCarousel = await _carouselRepo.GetCarouselByIdAsync(id);

            if(existingCarousel == null)
            {
                return Ok("The carousel item does not exist.");
            }

            return Ok(existingCarousel);
        }

        [HttpPost]
        public async Task<IActionResult> CreateCarouselItemAsync([FromBody] CreatedCarouselItemDto createdCarouselItemDto)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var newCarouselItemModel = createdCarouselItemDto.ToCarouselItemFromCreated();
            var createdCarousalItem = await _carouselRepo.CreateCarouselItemAsync(newCarouselItemModel);

            return CreatedAtAction(nameof(GetCarouselById), new { id = createdCarousalItem.CarouselId }, createdCarousalItem);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCarouselItemAsync([FromBody] UpdatedCarouselItemDto updatedCarouselItemDto, [FromRoute] int id)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var updatedCarouselItemModel = updatedCarouselItemDto.ToCarouselItemFromUpdated();
            
            var exisitngCarouselItem = await _carouselRepo.UpdateCarouselItemAsync(updatedCarouselItemModel, id);

            if(exisitngCarouselItem == null)
            {
                return Ok("The carousel item does not exist.");
            }

            return Ok(exisitngCarouselItem);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCarousalItemAsync([FromRoute] int id)
        {
            var existingCarousalItem = await  _carouselRepo.DeleteCarousalItemAsync(id);

            if(existingCarousalItem == null)
            {
                return Ok("The carousel item does not exist.");
            }

            return NoContent();
        }
    }
}

﻿using System.Text;
using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Dtos.UserDto;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        // i really would like to use Identity (but the Id would be string and therefore i have change a lot of places T_T)
        // now i have to hash the password by hand T_T
        //private readonly UserManager<User> _userManager;
        private readonly LibraryDbContext _context;

        public AccountController(LibraryDbContext context)
        {
            //_userManager = userManager;
            _context = context;
        }

        [HttpPost("register")]
        public async Task<IActionResult> register([FromBody] RegisterUserDto registerUserDto)
        {
                if(!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                if (await _context.Users.AnyAsync(u => u.Email == registerUserDto.Email))
                    return BadRequest("Username or Email already exists");

                using var sha256 = System.Security.Cryptography.SHA256.Create();
                var hashedPassword = Convert.ToBase64String(sha256.ComputeHash(Encoding.UTF8.GetBytes(registerUserDto.Password)));

                var activeCode = Guid.NewGuid().ToString();

                var user = new User
                {
                    Fullname = registerUserDto.Fullname,
                    Description = registerUserDto.Description,
                    Password = hashedPassword,
                    Email = registerUserDto.Email,
                    Phone = registerUserDto.Phone,
                    Address = registerUserDto.Address,
                    Status = 1,
                    CreatedDate = DateTime.UtcNow,
                    UserCode = Guid.NewGuid().ToString(),
                    IsLocked = false,
                    IsDeleted = false,
                    IsActive = false, 
                    ActiveCode = activeCode,
                    Avatar = registerUserDto.Avatar
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                Console.WriteLine($"Activation link: https://tuoiapp.com/api/users/activate?code={activeCode}");

                return Ok(activeCode);
        }

        [HttpGet("activate")]
        public async Task<IActionResult> Activate([FromQuery] string code)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.ActiveCode == code);

            if (user == null)
                return NotFound("Invalid activation code");

            user.IsActive = true;
            await _context.SaveChangesAsync();

            return Ok("User activated successfully.");
        }
    }
}

﻿using LeThiMinhTuoi_Lab4_dotnet.Data;
using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using LeThiMinhTuoi_Lab4_dotnet.Mappers;
using LeThiMinhTuoi_Lab4_dotnet.Models;
using Microsoft.AspNetCore.Mvc;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/author")]
    [ApiController]
    public class AuthorController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepo;

        public AuthorController(IAuthorRepository authorRepository)
        {
            _authorRepo = authorRepository;
        }

        [HttpGet]
        public async Task<IActionResult> getAllAuthor([FromQuery] QueryObjectAuthor query)
        {
            var authors = await _authorRepo.getAllAuthor(query);

            return Ok(authors);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetAuthorById([FromRoute] int id)
        {
            var existingAuthor = await _authorRepo.GetAuthorByIdAsync(id);

            if(existingAuthor == null)
            {
                return Ok("Author not found.");
            }

            return Ok(existingAuthor);
        }

        [HttpPost]
        public async Task<IActionResult> AddAuthor([FromBody] CreatedAuthorDto createdAuthorDto)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var authorModel = createdAuthorDto.AuthorFromCreatedAuthorDto();

            var createdAuthor = await _authorRepo.AddAuthorAsync(authorModel);

            if(createdAuthor == null)
            {
                return Ok("Author not found");
            }

            return CreatedAtAction(nameof(GetAuthorById), new { id = createdAuthor.AuthorId }, createdAuthor);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAuthor([FromBody] UpdatedAuthorDto updatedAuthorDto, [FromRoute] int id)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            
            var authorModel = updatedAuthorDto.AuthorFromUpdateddAuthorDto();

            var existingAuthor = await _authorRepo.UpdateAuthorAsync(authorModel, id);

            if(existingAuthor == null)
            {
                return Ok("Author not found");
            }

            return Ok(existingAuthor);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAuthor([FromRoute] int id)
        { 
            var existingAuthor = await _authorRepo.DeleteAuthorAsync(id);

            if( existingAuthor == null)
            {
                return Ok("Author not found");
            }

            return NoContent();
        }
    }
}

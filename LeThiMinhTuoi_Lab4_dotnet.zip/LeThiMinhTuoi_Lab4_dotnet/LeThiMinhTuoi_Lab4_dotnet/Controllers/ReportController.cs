﻿using LeThiMinhTuoi_Lab4_dotnet.Helpers;
using LeThiMinhTuoi_Lab4_dotnet.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace LeThiMinhTuoi_Lab4_dotnet.Controllers
{
    [Route("api/reports")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly IReportRepository _reportRepository;

        public ReportController(IReportRepository reportRepository)
        {
            _reportRepository = reportRepository;
        }

        [HttpGet("top-borrowed")]
        public async Task<IActionResult> getTopBorrowedBooks([FromQuery] QueryObjectTopBook query)
        {
            var topBooks = await _reportRepository.GetTopBorrowedBooksAsync(query);

            return Ok(topBooks);
        }
    }
}

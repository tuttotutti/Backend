﻿using Microsoft.AspNetCore.Identity;

namespace LeThiMinhTuoi_Lab6_Backend.Models
{
    public class AppUser : IdentityUser
    {
    }
}

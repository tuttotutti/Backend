﻿using LeThiMinhTuoi_Lab6_Backend.Interfaces;
using LeThiMinhTuoi_Lab6_Backend.Models;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;

namespace LeThiMinhTuoi_Lab6_Backend.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly UserManager<AppUser> _userManager;

        public UserRepository(UserManager<AppUser> userManager)
        {
            _userManager = userManager;
        }

        public async Task<AppUser> GetUserByNameAsync(string username)
        {
            var receiverUser = await _userManager.FindByNameAsync(username);
            return receiverUser;
        }
    }
}
